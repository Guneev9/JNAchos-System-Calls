package jnachos.kern;

//since, for multiprogramming to function, we need to call startProcess multiple times 
//for that i have created a separate class in order to keep original code intact
//this class will create VoidFunctionPtr to startProcess function for each argument(each file)
//i got this idea from ProcessTest.java class 
public class Multiprogramme implements VoidFunctionPtr
{
	public void call(Object pArg) 
	
	{
	//we are invoking startProcess with argument name
		//this will start user process written on command line, run user program
		//it will open the file, save it in memory, set register values and jump to user program by
		//calling machine.run() which simulate the execution of user program on jnachos
		JNachos.startProcess(pArg.toString());
	}
}
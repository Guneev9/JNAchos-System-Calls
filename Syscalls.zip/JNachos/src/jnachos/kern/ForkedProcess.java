package jnachos.kern;

import jnachos.machine.Machine;


//This is new Class like i did for multiprogramming lab in order to avoid changes in existing code

public class ForkedProcess implements VoidFunctionPtr 
{
	public void call(Object pArg)
	{
		
		//Restore Registers for this process
		JNachos.getCurrentProcess().restoreUserState();
		
		//it will restore address space for this process 
		JNachos.getCurrentProcess().getSpace().restoreState();
		
		//Now jump to the user program by calling machine.run()
		//as,we now it will never return
		Machine.run();
	}	
			
	}

